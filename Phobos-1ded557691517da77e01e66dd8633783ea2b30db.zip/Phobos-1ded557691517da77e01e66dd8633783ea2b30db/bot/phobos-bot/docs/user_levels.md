# Уровни пользователей (User Levels)

## Обзор

Phobos Bot использует систему уровней пользователей для управления правами доступа и ограничениями. Уровень пользователя определяет доступные команды, лимиты и привилегии.

## Структура таблицы `users`

```sql
CREATE TABLE users (
    user_id INTEGER PRIMARY KEY,              -- ID пользователя в Telegram
    username TEXT NOT NULL,                    -- Имя пользователя (@username)
    user_level TEXT DEFAULT 'basic',          -- Уровень доступа
    premium_expires_at DATETIME,              -- Дата истечения премиум-статуса
    premium_reason TEXT,                      -- Причина предоставления премиума
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,  -- Дата регистрации
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP   -- Дата последнего обновления
);
```

## Доступные уровни пользователей

### 1. Basic (Обычный пользователь)

**Значение:** `user_level = 'basic'`

**Описание:**
Стандартный уровень для всех новых пользователей. Имеет базовые функции с ограничениями.

**Доступные команды:**
- `/start` - приветствие и информация о боте
- `/create` - создание конфигурации (с ограничениями)
- `/stat` - статус текущей конфигурации
- `/delete` - удаление конфигурации
- `/info` - информация о сервисе
- `/selfhost` - информация о самостоятельном хостинге
- `/help` - справка по командам
- `/feedback` - обратная связь
- `/premium` - информация о премиум-статусе

**Ограничения:**
- ⏱ **Тестовый период**: ограничен `max_test_duration` (по умолчанию 72 часа с момента регистрации)
  - После истечения: доступны все команды КРОМЕ `/create`
  - Просмотр статуса, удаление, feedback остаются доступными
- 🔄 **Rate limiting**: ограничение частоты выполнения команды `/create`
- 🗑 **Watchdog**: конфигурация автоматически удаляется при неактивности > `watchdog_inactive_threshold` (по умолчанию 24 часа)
- 📊 **Лимит подключений**: учитывается в общем пуле `max_clients`
- 🆕 **Новые пользователи**: может быть ограничено создание конфигураций для новых аккаунтов (настраивается)

**Связанные поля таблицы:**
- `premium_expires_at`: NULL
- `premium_reason`: NULL
- `created_at`: используется для расчета тестового периода

**Переход на другой уровень:**
```sql
-- Вручную через SQL
UPDATE users SET user_level = 'premium' WHERE user_id = 123456789;

-- Через команду администратора
/setlevel 123456789 premium
/setpremium 123456789 30  -- Рекомендуется для premium
```

---

### 2. Premium (Премиум пользователь)

**Значение:** `user_level = 'premium'`

**Описание:**
Платный уровень доступа с расширенными привилегиями и снятием ограничений.

**Доступные команды:**
Все команды уровня Basic без ограничений

**Привилегии:**
- ✅ **Без тестового периода**: `/create` доступен всегда, независимо от `max_test_duration`
- ✅ **Без rate limiting**: команда `/create` доступна без задержек
- ✅ **Защита от watchdog**: конфигурация НЕ удаляется автоматически при неактивности
- ✅ **Вне лимита подключений**: не учитывается в `max_clients`
- ✅ **Приоритет**: операции выполняются с приоритетом

**Ограничения:**
Нет (кроме срока действия премиума)

**Связанные поля таблицы:**

#### `premium_expires_at` (DATETIME, nullable)
**Назначение:** Дата и время истечения премиум-статуса

**Возможные значения:**
- `NULL` - бессрочный премиум
- `YYYY-MM-DD HH:MM:SS` - дата истечения

**Примеры:**
```sql
-- Премиум до 31 декабря 2025
premium_expires_at = '2025-12-31 23:59:59'

-- Бессрочный премиум
premium_expires_at = NULL
```

**Проверка:**
```sql
-- Активные премиум-пользователи
SELECT * FROM users
WHERE user_level = 'premium'
AND (premium_expires_at IS NULL OR premium_expires_at > datetime('now'));

-- Истекшие премиум-аккаунты
SELECT * FROM users
WHERE user_level = 'premium'
AND premium_expires_at IS NOT NULL
AND premium_expires_at <= datetime('now');
```

**Логика проверки:**
```go
// Из internal/database/user_repository.go
func (ur *UserRepository) IsPremium(userID int64) (bool, error) {
    // Админы и модераторы всегда premium
    if userLevel == "admin" || userLevel == "moderator" {
        return true, nil
    }

    // Проверка уровня premium
    if userLevel != "premium" {
        return false, nil
    }

    // Если дата не указана (NULL) - бессрочный
    if !expiresAt.Valid {
        return true, nil
    }

    // Проверка срока действия
    return time.Now().Before(expiresAt.Time), nil
}
```

#### `premium_reason` (TEXT, nullable)
**Назначение:** Причина предоставления премиум-статуса (для учета)

**Примеры значений:**
- `"Оплата через PayPal, invoice #12345"`
- `"Продление, карта ****1234"`
- `"Спонсор проекта"`
- `"Компенсация за технические проблемы"`
- `"Тестовый доступ для партнера"`

**Использование:**
```sql
-- Установка через SQL
UPDATE users
SET premium_reason = 'Оплата через Stripe, #invoice-67890'
WHERE user_id = 123456789;

-- Через команду /setpremium (автоматически)
/setpremium 123456789 30 Оплата через PayPal
```

**Примечания:**
- Поле опциональное, но рекомендуется заполнять для аудита
- Помогает отслеживать источники премиум-доступа
- Полезно при разборе споров и возвратах

**Установка премиум-статуса:**
```bash
# Премиум на 30 дней с причиной
/setpremium 123456789 30 Оплата через PayPal, #invoice-12345

# Бессрочный премиум
/setpremium 987654321 permanent Спонсор проекта

# Только через SQL (без причины)
UPDATE users
SET user_level = 'premium',
    premium_expires_at = datetime('now', '+30 days'),
    updated_at = CURRENT_TIMESTAMP
WHERE user_id = 123456789;
```

**Автоматическая проверка:**
- Система проверяет срок действия при каждом вызове `IsPremium()`
- Истекший премиум автоматически теряет привилегии (но уровень остается 'premium')
- Рекомендуется периодически очищать истекшие аккаунты:
```sql
UPDATE users
SET user_level = 'basic',
    premium_expires_at = NULL,
    premium_reason = NULL
WHERE user_level = 'premium'
AND premium_expires_at IS NOT NULL
AND premium_expires_at <= datetime('now');
```

---

### 3. Moderator (Модератор)

**Значение:** `user_level = 'moderator'`

**Описание:**
Привилегированный уровень для поддержки пользователей и мониторинга системы.

**Доступные команды:**
Все команды Premium + административные команды для мониторинга:
- `/logs` - просмотр логов событий
- `/users` - список пользователей
- `/feedbacklist` - список обратной связи

**Привилегии:**
- ✅ **Все премиум-привилегии**: без ограничений, защита от watchdog, вне лимитов
- ✅ **Мониторинг**: доступ к логам и статистике пользователей
- ✅ **Поддержка**: обработка обратной связи
- ✅ **Автоматический премиум**: `IsPremium()` возвращает `true` для модераторов

**Ограничения:**
- ❌ **Нет управления пользователями**: не может менять уровни или блокировать
- ❌ **Нет конфигурации системы**: не может менять настройки
- ❌ **Нет управления резервными копиями**

**Связанные поля таблицы:**
- `premium_expires_at`: игнорируется (модераторы всегда имеют премиум-привилегии)
- `premium_reason`: может быть пустым или содержать причину назначения модератором

**Назначение модератора:**
```bash
# Через команду администратора
/setlevel 123456789 moderator

# Или через SQL
UPDATE users
SET user_level = 'moderator',
    updated_at = CURRENT_TIMESTAMP
WHERE user_id = 123456789;
```

**Особенности:**
- Модераторы получают уведомления о новой обратной связи
- При отправке feedback модератором, другие видят только кнопку "Прочитано"
- Полезно для делегирования задач поддержки без полного доступа

---

### 4. Admin (Администратор)

**Значение:** `user_level = 'admin'`

**Описание:**
Высший уровень доступа с полным контролем над системой.

**Доступные команды:**
Все команды Moderator + команды управления системой:
- `/setlevel` - изменение уровня пользователя
- `/setpremium` - установка премиум-статуса
- `/block` - блокировка пользователя
- `/unblock` - разблокировка пользователя
- `/config` - управление конфигурацией системы
- `/stats` - статистика системы
- `/cleanuplogs` - очистка старых логов
- `/backup` - управление резервными копиями

**Привилегии:**
- ✅ **Полный контроль**: все функции бота
- ✅ **Все премиум-привилегии**: автоматически
- ✅ **Управление пользователями**: изменение уровней, блокировка
- ✅ **Конфигурация системы**: изменение параметров
- ✅ **Резервное копирование**: создание и восстановление
- ✅ **Полная обработка feedback**: ответы, изменение уровней, удаление конфигураций

**Ограничения:**
Нет

**Связанные поля таблицы:**
- `premium_expires_at`: игнорируется
- `premium_reason`: может содержать информацию о назначении администратором

**Назначение администратора:**
```bash
# ТОЛЬКО через SQL (безопасность!)
# Первый администратор создается вручную
UPDATE users
SET user_level = 'admin',
    updated_at = CURRENT_TIMESTAMP
WHERE user_id = 1458954246;

# Последующие через команду другого администратора
/setlevel 987654321 admin
```

**Примечания:**
- ⚠️ Будьте осторожны с назначением администраторов
- Рекомендуется минимальное количество (2-3)
- Все действия администраторов логируются
- Первый администратор создается вручную через SQL

---

## Сравнительная таблица

| Параметр | Basic | Premium | Moderator | Admin |
|----------|-------|---------|-----------|-------|
| **Доступ к /create** | Ограничен тестовым периодом | Без ограничений | Без ограничений | Без ограничений |
| **Rate limiting** | Да | Нет | Нет | Нет |
| **Watchdog удаление** | Да | Нет | Нет | Нет |
| **Учет в max_clients** | Да | Нет | Нет | Нет |
| **Срок действия** | - | premium_expires_at | - | - |
| **Мониторинг (/logs, /users)** | Нет | Нет | Да | Да |
| **Обратная связь (/feedbacklist)** | Нет | Нет | Да | Да |
| **Управление пользователями** | Нет | Нет | Нет | Да |
| **Конфигурация системы** | Нет | Нет | Нет | Да |
| **Резервное копирование** | Нет | Нет | Нет | Да |

---

## Зависимые поля таблицы `users`

### `created_at` (DATETIME, NOT NULL)
**Назначение:** Дата и время регистрации пользователя

**Использование:**
- Расчет тестового периода для basic пользователей
- Статистика роста пользовательской базы
- Определение "новых" пользователей

**Пример проверки тестового периода:**
```go
// Из internal/handler.go
if !isPremium && !isPrivileged && h.config.MaxTestDuration > 0 {
    if time.Since(user.CreatedAt) >= h.config.MaxTestDuration {
        // Тестовый период истек
        // Показать сообщение о необходимости премиума
    }
}
```

**SQL запросы:**
```sql
-- Пользователи, зарегистрированные сегодня
SELECT * FROM users WHERE DATE(created_at) = DATE('now');

-- Пользователи с истекшим тестовым периодом (72 часа)
SELECT * FROM users
WHERE user_level = 'basic'
AND created_at < datetime('now', '-72 hours');

-- Статистика регистраций по дням
SELECT DATE(created_at) as date, COUNT(*) as count
FROM users
GROUP BY DATE(created_at)
ORDER BY date DESC;
```

---

### `updated_at` (DATETIME, NOT NULL)
**Назначение:** Дата и время последнего обновления записи

**Автоматическое обновление:**
При любом изменении записи пользователя:
- Изменение уровня (`/setlevel`)
- Установка премиума (`/setpremium`)
- Обновление имени пользователя

**Использование:**
- Отслеживание активности изменений
- Аудит операций с пользователями
- Синхронизация данных

**SQL запросы:**
```sql
-- Недавно обновленные пользователи
SELECT * FROM users
WHERE updated_at > datetime('now', '-7 days')
ORDER BY updated_at DESC;

-- Пользователи без изменений более года
SELECT * FROM users
WHERE updated_at < datetime('now', '-1 year');
```

---

### `username` (TEXT, NOT NULL)
**Назначение:** Telegram username пользователя

**Примечания:**
- Может изменяться (пользователь меняет @username в Telegram)
- Используется для идентификации в логах и уведомлениях
- Индексируется для быстрого поиска
- Не уникальное (пользователи могут удалять username)

**Обновление:**
```go
// Автоматически при каждом сообщении
err := h.userRepo.RegisterUser(update.Message.From.ID, update.Message.From.UserName)
```

---

### `user_id` (INTEGER, PRIMARY KEY)
**Назначение:** Уникальный ID пользователя в Telegram

**Примечания:**
- Никогда не меняется
- Используется как основной идентификатор
- Первичный ключ таблицы

---

## Логика проверки привилегий

### `IsPremium()` - Проверка премиум-статуса

```go
func (ur *UserRepository) IsPremium(userID int64) (bool, error) {
    var userLevel string
    var expiresAt sql.NullTime

    // Получить уровень и дату истечения
    err := ur.db.QueryRow(`
        SELECT user_level, premium_expires_at
        FROM users
        WHERE user_id = ?
    `, userID).Scan(&userLevel, &expiresAt)

    // Admin и Moderator автоматически премиум
    if userLevel == "admin" || userLevel == "moderator" {
        return true, nil
    }

    // Проверка premium уровня
    if userLevel != "premium" {
        return false, nil
    }

    // NULL = бессрочный премиум
    if !expiresAt.Valid {
        return true, nil
    }

    // Проверка срока действия
    return time.Now().Before(expiresAt.Time), nil
}
```

**Результаты:**
- `true` - для admin, moderator, или действующего premium
- `false` - для basic или истекшего premium

---

### `checkPrivilege()` - Проверка уровня доступа

```go
func (h *BotHandler) checkPrivilege(user *User, requiredLevel UserLevel) bool {
    userLevel := user.UserLevel

    switch requiredLevel {
    case Admin:
        return userLevel == string(Admin)
    case Moderator:
        return userLevel == string(Admin) || userLevel == string(Moderator)
    case Premium:
        isPremium, _ := h.userRepo.IsPremium(user.UserID)
        return isPremium
    case Basic:
        return true
    default:
        return false
    }
}
```

**Иерархия:**
- Admin имеет доступ к Moderator, Premium, Basic
- Moderator имеет доступ к Premium, Basic (но НЕ Admin)
- Premium имеет доступ к Basic
- Basic имеет доступ только к Basic

---

## Примеры работы с уровнями

### Пример 1: Регистрация нового пользователя
```sql
INSERT INTO users (user_id, username, user_level, created_at, updated_at)
VALUES (123456789, 'newuser', 'basic', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
```

**Результат:**
- `user_level = 'basic'`
- `premium_expires_at = NULL`
- `premium_reason = NULL`
- Тестовый период начинается с `created_at`

---

### Пример 2: Продажа премиума на 30 дней
```bash
/setpremium 123456789 30 Оплата через PayPal, invoice #12345
```

**SQL эквивалент:**
```sql
UPDATE users
SET user_level = 'premium',
    premium_expires_at = datetime('now', '+30 days'),
    premium_reason = 'Оплата через PayPal, invoice #12345',
    updated_at = CURRENT_TIMESTAMP
WHERE user_id = 123456789;
```

**Результат:**
- `user_level = 'premium'`
- `premium_expires_at = '2025-12-16 10:30:00'` (пример)
- `premium_reason = 'Оплата через PayPal, invoice #12345'`
- Все ограничения сняты

---

### Пример 3: Бессрочный премиум для спонсора
```bash
/setpremium 987654321 permanent Спонсор проекта, $100/месяц
```

**SQL эквивалент:**
```sql
UPDATE users
SET user_level = 'premium',
    premium_expires_at = NULL,
    premium_reason = 'Спонсор проекта, $100/месяц',
    updated_at = CURRENT_TIMESTAMP
WHERE user_id = 987654321;
```

**Результат:**
- `user_level = 'premium'`
- `premium_expires_at = NULL` (бессрочно)
- `premium_reason = 'Спонсор проекта, $100/месяц'`

---

### Пример 4: Назначение модератора
```bash
/setlevel 555555555 moderator
```

**SQL эквивалент:**
```sql
UPDATE users
SET user_level = 'moderator',
    updated_at = CURRENT_TIMESTAMP
WHERE user_id = 555555555;
```

**Результат:**
- `user_level = 'moderator'`
- `premium_expires_at` игнорируется (всегда премиум)
- Доступ к командам мониторинга

---

### Пример 5: Истечение премиума

Пользователь с:
- `user_level = 'premium'`
- `premium_expires_at = '2025-11-15 23:59:59'`

**Что происходит после 2025-11-15 23:59:59:**
- `IsPremium()` возвращает `false`
- Применяются ограничения basic пользователя
- `user_level` остается 'premium' (не меняется автоматически)
- `/create` блокируется (если истек тестовый период)

**Рекомендуется периодически очищать:**
```sql
UPDATE users
SET user_level = 'basic',
    premium_expires_at = NULL,
    premium_reason = NULL,
    updated_at = CURRENT_TIMESTAMP
WHERE user_level = 'premium'
AND premium_expires_at IS NOT NULL
AND premium_expires_at <= datetime('now', '-30 days');
```

---

## Рекомендации

### Для Basic пользователей
- Четко информируйте о тестовом периоде
- Показывайте оставшееся время в `/stat`
- Предлагайте переход на premium до истечения

### Для Premium пользователей
- Всегда заполняйте `premium_reason` для аудита
- Используйте `/setpremium` вместо прямого SQL
- Уведомляйте пользователей за 7 дней до истечения
- Предлагайте продление

### Для Moderator
- Назначайте только проверенных пользователей
- Ограничьте количество модераторов (5-10)
- Регулярно проверяйте активность
- Документируйте назначения

### Для Admin
- Минимальное количество (2-3)
- Используйте двухфакторную аутентификацию Telegram
- Регулярно проверяйте логи действий
- Первый admin создавайте вручную через SQL

---

## Миграция между уровнями

### Basic → Premium
```bash
/setpremium <user_id> <days> <reason>
```

### Premium → Basic (истечение)
```sql
UPDATE users
SET user_level = 'basic',
    premium_expires_at = NULL,
    premium_reason = NULL
WHERE user_id = ?;
```

### Basic/Premium → Moderator
```bash
/setlevel <user_id> moderator
```

### Moderator → Admin
```bash
/setlevel <user_id> admin
```

### Admin → Moderator (понижение)
```bash
/setlevel <user_id> moderator
```

### Любой → Basic (сброс)
```bash
/setlevel <user_id> basic
```

---

## Безопасность

### Важно:
- ⚠️ Первого администратора создавайте ТОЛЬКО через прямой доступ к БД
- ⚠️ Проверяйте `user_id` перед назначением admin
- ⚠️ Логируйте все изменения уровней
- ⚠️ Регулярно проверяйте список администраторов
- ⚠️ Используйте `premium_reason` для аудита
